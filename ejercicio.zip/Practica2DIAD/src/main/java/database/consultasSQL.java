package database;

public class consultasSQL {
    public static String comprobarUsuario = "FROM Usuario u WHERE u.nombreUsuario = :usuarioArgs "
                                            + "AND u.contrasenia = :contraseniaArgs "
                                            + "AND u.rol = :cargoArgs";
}
