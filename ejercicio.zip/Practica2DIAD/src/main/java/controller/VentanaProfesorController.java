package controller;

public class VentanaProfesorController {
}
