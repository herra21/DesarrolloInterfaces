package controller;

public class VentanaAlumnoController {
}
