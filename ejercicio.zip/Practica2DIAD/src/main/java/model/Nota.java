package model;

public class Nota {
}
