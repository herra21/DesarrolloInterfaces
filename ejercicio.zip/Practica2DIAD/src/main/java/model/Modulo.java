package model;

public class Modulo {
}
