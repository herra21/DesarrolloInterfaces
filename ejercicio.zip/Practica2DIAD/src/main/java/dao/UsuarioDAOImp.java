package dao;

import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import model.Usuario;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import static database.consultasSQL.comprobarUsuario;

public class UsuarioDAOImp implements UsuarioDAO{

    private Session session;
    private Transaction transaction;

    private Usuario usuario;

    @Override
    public Usuario iniciarSesion(String nombreUsuario, String contrasenia, String cargo) {

        session = new Configuration().configure().buildSessionFactory().openSession();

        Query<Usuario> query = session.createQuery(comprobarUsuario, Usuario.class);
        query.setParameter("usuarioArgs", nombreUsuario);
        query.setParameter("contraseniaArgs", contrasenia);
        query.setParameter("cargoArgs", cargo);

        usuario = query.uniqueResult();

        session.close();

        return usuario;

    }
}
